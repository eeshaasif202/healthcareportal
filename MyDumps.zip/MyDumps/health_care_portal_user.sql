-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: health_care_portal
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `user_info_id` int DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `hospital_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  KEY `user_role_id` (`role_id`),
  KEY `user_user_info_id` (`user_info_id`),
  KEY `user_hospital_id_idx` (`hospital_id`),
  CONSTRAINT `user_hospital_id` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`id`),
  CONSTRAINT `user_role_id` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `user_user_info_id` FOREIGN KEY (`user_info_id`) REFERENCES `user_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'eeshaasif2@gmail.com','03181234567','Eesha','$2a$10$uGwM7qU0a.qGdLfjRyMD0OSgi4ak1M1LaruTieU9fAG2.ZwI0iW3O','female',3,'2023-11-19 15:59:37',1,'Eesha',NULL),(26,'doc@gmail.com','24234','doc','$2a$10$q2f9cB3MAUBmpWZzkIr18.MuHjlUrGcLbr.bih6XzJNaurhTaFRpi','male',2,'2023-12-17 14:02:35',NULL,'doc',NULL),(27,'admin@gmail.com','1324325','Admin','$2a$10$eao1xvpUIVjyqQpd9uCX6ORbThDTcjWaD19AG6hwqQwHvFAKfIV7W','male',1,'2023-12-17 20:02:14',NULL,'admin',NULL),(28,'patient@gmail.com','23543262436','Patient','$2a$10$AdHVuH0wpVbpDstxpKgiPu5avC.Wp7/BbnNn/uepwjfDaHKBA4Gz.','male',3,'2023-12-18 22:08:34',NULL,'pat',NULL),(32,'systemadmin@gmail.com','03121234567','SystemAdmin','$2a$10$mWdVSALyVSNJbL6cTZ22a.FhXpT3RNrMyWcGWnCn2lAC8ii4PwPCu','male',NULL,'2024-05-08 18:50:34',NULL,'systemadmin',NULL),(34,'systemadmin2@gmail.com','03121234567','SystemAdmin2','$2a$10$onxlh0xGb0veR5RkQRv5OOtN6sP7NbhX2Flzbbn2k.C8Ahzu1uoRm','male',NULL,'2024-05-08 18:50:50',NULL,'systemadmin2',NULL),(36,'SA1@gmail.com','03141234567','SA','$2a$10$lj5rfq7BGQCLlTZrfcSiB.7VOHO4QoUk8bZSpMi5D.JuTaNN85yMC','male',4,'2024-05-08 18:52:43',NULL,'SA1',NULL),(37,'ayeshasadiq@gmail.com','03121234567','AyeshaSadiq','$2a$10$D9UGNWDh6AOelb2Ty2j7u.OEzA93WuLz6DrKnP49j7a7MXjQ/kps.','female',3,'2024-05-08 19:25:46',NULL,'ayeshasadiq',NULL),(38,'Noman@gmail.com','03121234567','Noman','$2a$10$SoPg2QvgLVERcyu1njqhnumEFs4eEgktUta8mQCm3.nY3YOUg1SZ6','male',2,'2024-05-09 09:48:06',NULL,'Noman',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-09 10:16:27
