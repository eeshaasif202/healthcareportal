import React from 'react'

const Rooms = () => {
  return (
    <div>
      <h1> Add Rooms</h1>
    </div>
  )
}

export default Rooms
