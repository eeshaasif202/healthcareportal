import React from 'react'
import PatientDashboard from '../Components/Patient/PatientDashboard'
const Patient = () => {
  return (
    <div>
       <PatientDashboard/>
      
    </div>
  )
}

export default Patient