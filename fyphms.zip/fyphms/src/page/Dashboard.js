import React from 'react'


import Sidebar from '../Components/Admin/sidebar'
const Dashboard = () => {
  return (
    <div>
        <Sidebar />
      
    </div>
  )
}

export default Dashboard