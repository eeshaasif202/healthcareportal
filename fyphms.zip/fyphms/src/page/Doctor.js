import React from 'react'
import DoctorDashboard from '../Components/Doctor/DoctorDashboard'
const Doctor = () => {
  return (
    <div>
       <DoctorDashboard/>
      
    </div>
  )
}

export default Doctor