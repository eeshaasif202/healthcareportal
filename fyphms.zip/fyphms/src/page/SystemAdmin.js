import React from 'react'
import DoctorDashboard from '../Components/Doctor/DoctorDashboard'
import SystemAdminDashboard from '../Components/SystemAdmin/SystemAdminDashboard'
const SystemAdmin = () => {
  return (
    <div>
       <SystemAdminDashboard/>
       
       
      
    </div>
  )
}

export default SystemAdmin