
package com.portal.healthcare.model;

import lombok.Data;

@Data
public class TestDTO {
    private int id;
    private String status;
    private String name;
    private int patientId;
}