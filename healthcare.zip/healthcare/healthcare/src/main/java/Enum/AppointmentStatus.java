package Enum;

public enum AppointmentStatus {
    incomplete,pending, in_progress, complete
}
